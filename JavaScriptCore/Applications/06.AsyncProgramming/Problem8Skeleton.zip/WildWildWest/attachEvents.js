function attachEvents() {
    //TODO
}