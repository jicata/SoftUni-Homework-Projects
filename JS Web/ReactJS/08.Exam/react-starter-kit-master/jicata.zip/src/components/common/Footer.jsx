import React, { Component } from 'react';

export default class Header extends Component {
    render() {

        return (
            <footer>
                <div className="container modal-footer">
                    <p>Budget Planner &copy; SoftUni 2017</p>
                </div>
            </footer>
        );
    }
}