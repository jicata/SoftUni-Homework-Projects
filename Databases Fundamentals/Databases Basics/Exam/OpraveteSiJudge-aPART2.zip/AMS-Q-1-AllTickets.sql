SELECT t.TickedID,
		t.Price,
		t.Class,
		t.Seat
FROM Tickets AS t
ORDER BY t.TickedID