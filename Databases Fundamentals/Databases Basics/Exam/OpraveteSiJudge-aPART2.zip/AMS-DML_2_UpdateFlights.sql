UPDATE Flights
SET AirlineID = 1
WHERE [Status] = 'Arrived'