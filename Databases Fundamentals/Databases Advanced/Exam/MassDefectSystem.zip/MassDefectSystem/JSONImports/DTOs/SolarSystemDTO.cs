﻿namespace JSONImports.DTOs
{
    public class SolarSystemDTO
    {
        public string Name { get; set; }
    }
}
