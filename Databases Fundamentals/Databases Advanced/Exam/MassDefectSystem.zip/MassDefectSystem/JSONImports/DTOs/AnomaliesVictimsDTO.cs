﻿namespace JSONImports.DTOs
{
    public class AnomaliesVictimsDTO
    {
        public int Id { get; set; }

        public string Person { get; set; }
    }
}
