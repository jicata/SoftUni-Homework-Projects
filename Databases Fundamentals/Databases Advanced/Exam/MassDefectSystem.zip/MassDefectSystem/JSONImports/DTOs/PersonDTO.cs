﻿namespace JSONImports.DTOs
{
    public class PersonDTO
    {       
        public string Name { get; set; }

        public string HomePlanet { get; set; }
    }
}
