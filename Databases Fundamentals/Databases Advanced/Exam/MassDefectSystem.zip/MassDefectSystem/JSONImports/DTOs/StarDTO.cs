﻿namespace JSONImports.DTOs
{
    public class StarDTO
    {
        public string Name { get; set; }

        public string SolarSystem { get; set; }

    }
}
