﻿namespace JSONImports.DTOs
{
    public class PlanetDTO
    {
        public string Name { get; set; }

        public string SolarSystem { get; set; }

        public string Sun { get; set; }
    }
}
