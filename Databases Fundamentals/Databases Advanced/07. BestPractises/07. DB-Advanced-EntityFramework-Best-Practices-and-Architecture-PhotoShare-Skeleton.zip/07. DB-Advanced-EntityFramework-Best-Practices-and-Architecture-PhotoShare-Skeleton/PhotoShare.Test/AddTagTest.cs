﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PhotoShare.Test
{
    [TestClass]
    public class AddTagTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
