﻿using System;

namespace PhotoShare.Client.Attributes
{
    internal class InsertAttribute : Attribute
    {
    }
}