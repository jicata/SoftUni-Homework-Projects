﻿namespace PhotoShare.Client.IO
{
    using System;
    using Interfaces;
    
    public class XmlWriter : IWriter
    {
        public void Write(string text)
        {
            throw new NotImplementedException();
        }

        public void WriteLine(string text)
        {
            throw new NotImplementedException();
        }
    }
}
