﻿namespace PhotoShare.Client.Interfaces
{
    public interface IRunnable
    {
        void Run(string start);
    }
}
