﻿namespace DossierSystem.Models
{
    public enum Status
    {
        Active = 0,
        Missing = 1,
        Deceased = 2
    }
}
