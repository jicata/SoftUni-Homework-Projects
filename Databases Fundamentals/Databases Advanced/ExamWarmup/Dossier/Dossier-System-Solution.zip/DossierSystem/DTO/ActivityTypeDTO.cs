﻿namespace DossierSystem.DTO
{
    public class ActivityTypeDTO
    {
        public string Name { get; set; }
    }
}
