﻿using System;


namespace Empire.Enums
{
    public enum ResourceTypes
    {
        Gold,
        Steel
    }
}
