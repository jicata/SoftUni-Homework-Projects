﻿using System;

namespace Empire.Interfaces
{
   public interface IUpdateable
   {
       void Update();
   }
}
