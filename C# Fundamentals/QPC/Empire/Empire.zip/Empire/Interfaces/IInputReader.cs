﻿using System;


namespace Empire.Engine
{
    public interface IInputReader
    {
        string ReadLine();
    }
}
