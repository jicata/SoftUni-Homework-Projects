﻿using System;


namespace Empire.Engine
{
    public interface IOutputWriter
    {
        void Print(string message);
    }
}
