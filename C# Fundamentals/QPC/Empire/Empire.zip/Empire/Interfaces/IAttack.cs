﻿using System;


namespace Empire.Interfaces
{
    public interface IAttack
    {
        int AttackDamage { get; }
    }
}
