﻿using System;


namespace Empire.Interfaces
{
    public interface IKillable
    {
        int Health { get; }
    }
}
