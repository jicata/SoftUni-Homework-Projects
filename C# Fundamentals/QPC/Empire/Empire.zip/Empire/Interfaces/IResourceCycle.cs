﻿using System;

namespace Empire.Interfaces
{
    public interface  IResourceCycle
    {
        int ResourceCycle { get; }
    }
}
