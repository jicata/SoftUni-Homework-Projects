﻿namespace ACTester.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
