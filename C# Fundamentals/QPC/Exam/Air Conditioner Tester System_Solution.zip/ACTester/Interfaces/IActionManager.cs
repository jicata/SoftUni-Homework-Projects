﻿namespace ACTester.Interfaces
{
    public interface IActionManager
    {
        string ExecuteCommand(ICommand action);
    }
}
