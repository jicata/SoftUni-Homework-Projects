﻿namespace ACTester.Enumerations
{
    public enum EnergyEfficiencyRating
    {
        A = 999,
        B = 1250,
        C = 1500,
        D = 2000,
        E = 2001
    }
}
