﻿namespace ACTester.Enumerations
{
    public enum Mark
    {
        Passed,
        Failed
    }
}
