﻿namespace SoftUniStore.Models.ViewModels
{
    public class DeleteGameViewModel 
    {
        public string Title { get; set; }

        public int Id { get; set; }
    }
}
