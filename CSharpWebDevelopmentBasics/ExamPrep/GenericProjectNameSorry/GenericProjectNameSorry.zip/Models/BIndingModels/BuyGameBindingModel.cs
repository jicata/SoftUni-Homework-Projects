﻿namespace SoftUniStore.Models.BIndingModels
{
    public class BuyGameBindingModel
    {
        public int Id { get; set; }
        
    }
}
