﻿namespace SoftUniStore.Models.BIndingModels
{
    public class DeleteGameBindingModel
    {
        public int Id { get; set; }
    }
}
