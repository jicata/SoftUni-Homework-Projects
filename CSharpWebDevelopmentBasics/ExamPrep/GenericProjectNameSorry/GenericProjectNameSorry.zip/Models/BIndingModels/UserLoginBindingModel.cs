﻿namespace SoftUniStore.Models.BIndingModels
{
    public class UserLoginBindingModel
    {
        public string Email { get; set; }

        public string Password { get; set; }

    }
}
