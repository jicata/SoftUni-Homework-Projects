﻿namespace SimpleMVC.Interfaces
{
    public interface IInvocable 
    {
        string Invoke();
    }
}
