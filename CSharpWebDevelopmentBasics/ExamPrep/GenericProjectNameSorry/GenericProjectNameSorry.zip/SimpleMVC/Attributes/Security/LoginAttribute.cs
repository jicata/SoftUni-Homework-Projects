﻿namespace SimpleMVC.App.MVC.Attributes.Security
{
    public class LoginAttribute : SecurityAttribute
    {

    }
}
